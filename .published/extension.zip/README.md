# Charlatan
Chrome extension that map a phone number to its Whatsapp API.
